package lk.ijse.bo;

public interface SuperBo {
}
