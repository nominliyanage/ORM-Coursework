package lk.ijse.entity.tm;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Setter

public class StudentTm {
    private String sid;
    private String name;
    private String address;
    private String tel;
    private String email;
}
