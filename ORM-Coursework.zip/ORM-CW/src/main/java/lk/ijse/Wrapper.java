package lk.ijse;
public class Wrapper {
    public static void main(String[] args) {
            Launcher.main(args);
    }
}